Compiler:

Default compiler is Google closure compiler. Please install Ant and Jre to build.
The shell files and Closure Compiler which Ant needs are provided in tools folder and cocos2d folder.

Reference wiki: http://www.cocos2d-x.org/projects/cocos2d-x/wiki/Closure_Compiler
For more on Google closure: https://developers.google.com/closure/compiler

