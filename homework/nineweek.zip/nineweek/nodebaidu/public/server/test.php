<?php
/**
 * Created by PhpStorm.
 * User: ymz
 * Date: 17-3-4
 * Time: 下午12:00
 */
phpinfo()
?>