<?php
/**
 * Created by PhpStorm.
 * User: ymz
 * Date: 17/3/2
 * Time: 下午3:58
 */
header("Content-type:application/json;charset=utf-8");
$link = mysqli_connect('127.0.0.1','root','123456','baidunews',3306);
?>