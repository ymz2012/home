xss防御
在nodebaidu/public/src/js/admin1.js的156行到176行定义了两个函数，对特殊字符进行转换和转出
csrf防御
传token 验证  没整好